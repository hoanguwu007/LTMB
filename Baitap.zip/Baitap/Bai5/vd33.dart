// Hàm trả về một chuỗi bất đồng bộ
Future<String> layten() async {
  return "Hoang Anh";
}

// Hàm tải dữ liệu, trả về một Future<String>
Future<String> taidulieu() {
  return Future.delayed(
    Duration(seconds: 2),
    () => "Dữ liệu đã tải xong",
  );
}

// Cách gọi hàm Future - Cách 1: sử dụng then()
void hamchinh1() {
  print("Bắt đầu tải dữ liệu...");
  Future<String> f = taidulieu();
  f.then((ketqua) {
    print("Kết quả: $ketqua");
  });
}

// Cách gọi hàm Future - Cách 2: sử dụng async/await
void hamchinh2() async {
  print("Bắt đầu tải..."); // 1
  String ketQua = await taidulieu();
  print("Kết quả: $ketQua"); // 2
  print("Tiếp tục công việc khác..."); // 3
}

// Hàm main - Điểm bắt đầu của chương trình
void main() {
  hamchinh2(); // Gọi hàm chính
}
