//kieu du lieu boolen
void main(){
  //bool: true | false
  bool x  = true;
  if(x){
    print("ok");
  }
  else{
    print("not ok");
  }
}