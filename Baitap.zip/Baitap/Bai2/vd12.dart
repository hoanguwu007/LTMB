/*
  Biểu thức 1 ? biểu thưc 2 : biểu thức 3;

  nếu bt1 đúng, trả về bt2  ngược lại, trả về bt3

  bt1 ?? bt2;

  nếu bt1 k null trả về giá trị của nó; ngược lại  trả về giá trị  bt2

 */
void main(){

  var kt = (100%2==0)?"100 la so chan" : "100 la so le";
  //neu 100 chia het so 2 thi 100 la so chan va nguoc lai
  print(kt);
  var x = 100;
  var y = x ?? 50;
  print(y);

  int? z;
   y = z??30;
  print(y);
}