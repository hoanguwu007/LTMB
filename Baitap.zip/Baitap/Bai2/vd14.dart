void main(){
  //int: so nguyen
  //double: so thuc

  int x=100;
  double y = 100.5;
  //num: co the so nguyen hoac so thuc

  num z = 10;
  num t = 10.75;
  var one = int.parse('1');
  print(one==1?'True':'false');
 //so thuc => chuoi
 String piAs = 3.14159.toStringAsFixed(2);
 print(piAs);
}