import 'dart:io';

void main(){

  //nhap ten 
  stdout.write('enter your name ');
  String name = stdin.readLineSync()!;

  //nhap tuoi
  stdout.write('enter your age ');
  int age = int.parse(stdin.readLineSync()!);
  print("xin chao: $name, tuoi cua bạn la: $age");
}