// Bài 1: List
void main() {
  // Có nhiều cách khai báo List:
  List<String> list1 = ['A', 'B', 'C']; // Cách thông thường
  var list2 = <String>['A', 'B', 'C']; // Sử dụng var 
  var list3 = List<int>.filled(3,0); // List có kích thước cố định [0,0,0]
  List<String> list4 = []; // Danh sách rỗng
  //Cho List ['A', 'B', 'C']. Viết code để:
  // Thao tác với List
  list1.add('D'); // Thêm 'D' vào cuối
  list1.insert(1, 'X'); // Chèn 'X' vào vị trí thứ 1
  list1.remove('B'); // Xóa phần tử 'B'
  print('Độ dài List: ${list1.length}');
  print("-------------------------------------------------");
  // Kết quả của đoạn code:
  var list = [1, 2, 3, 4, 5];
  list.removeWhere((e) => e % 2 == 0); //removewhere: duyệt từng phần tử và xóa phần tử nào thỏa mãn điều kiện
  print(list); 
  print("-------------------------------------------------");
  // So sánh phương thức:
  // remove() xóa giá trị cụ thể, removeAt() xóa theo chỉ số.
  // add() thêm một phần tử, insert() chèn phần tử vào vị trí cụ thể.
  // addAll() thêm nhiều phần tử, insertAll() chèn nhiều phần tử vào vị trí cụ thể.

  // Bài 2: Set
  var set1 = {1, 2, 3};
  var set2 = {3, 4, 5};
  
  print(set1.union(set2)); // Hợp: {1, 2, 3, 4, 5}
  print(set1.intersection(set2)); // Giao: {3}
  print(set1.difference(set2)); // Hiệu: {1, 2}
  
  var mySet = Set.from([1, 2, 2, 3, 3, 4]);
  print(mySet.length); // Output: 4 (Set không chứa phần tử trùng lặp)

  // Set khác List:
  // 1. Set không chứa phần tử trùng lặp.
  // 2. Set không có thứ tự cố định.
  // 3. Set có hiệu suất tìm kiếm nhanh hơn List.

  print("-------------------------------------------------");
  // Bài 3: Map
  Map<String, dynamic> user = {
    'name': 'Nam',
    'age': 20,
    'isStudent': true
  };

  user['email'] = 'nam@gmail.com'; // Thêm email
  user['age'] = 21; // Cập nhật age
  user.remove('isStudent'); // Xóa isStudent
  print(user.containsKey('phone')); // Kiểm tra key 'phone'
  print("-------------------------------------------------");
  // So sánh truy cập giá trị
  print(user['phone']); // null
  print(user['phone'] ?? 'Không có số điện thoại'); // 'Không có số điện thoại'
  
  // Hàm in key-value
  void printMap(Map<dynamic, dynamic> map) {
    map.forEach((key, value) => print('$key: $value'));
  }
  printMap(user);

  print("-------------------------------------------------");
  // Bài 4: Runes
  Runes emoji = Runes("\u1F600"); // Emoji cười 😀
  String emojiString = String.fromCharCodes(emoji);
  print(emojiString); // 😀
  print(emoji.length); // Số lượng điểm mã của Runes
}
