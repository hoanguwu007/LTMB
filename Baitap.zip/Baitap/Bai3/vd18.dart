void main(){
  // ĐỊNH NGHĨA: 
//List là tập hợp các phần tử có thứ tự và có thể trùng lặp 
//-Các phần tử được truy cập bằng chỉ số (index) từ 0 
//Kích thước có thể thay đổi được 

  List<String> list1 = ['A','B','C'];//Trực tiếp
  var lis2 = [1,2,3]; //sử dụng var
  List<String> list3 = [];//List rỗng
  var list4 = List<int>.filled(3,0); //List có kích thước cố định [0,0,0]
  print(list4);
  //1. thêm phần tử
  list1.add('D');//thêm 1 ptu
  list1.addAll(['A','C']);//thêm nhiều ptu
  list1.insert(0,'Z');//chèn 1 ptu

  list1.insertAll(1,['1','0']);//chèn nhiều ptu

  print(list1);
  //2.Xoa ptu ben trong list
  list1.remove('A');//xoa ptu co gtri A
  list1.removeAt(0);//xoa ptu tai vtri 0
  list1.removeLast;//xoa ptu tai vtri cuoi
  list1.removeWhere((e)=>e=='B');//xoa theo dieu kien
  list1.clear();
  print(list1);

  //3. truy cap ptu:
  print(lis2[0]);//lay ptu tai vtri 0
  print(lis2.first);//lay ptu dau tien
  print(lis2.last);//lay ptu cuoi cung
  print(lis2.length);//do dai cua list
  //4.kiem tra
  print(lis2.isEmpty);//kiem tra rong
  print('List 3: ${list3.isNotEmpty}');//kiem tra k rong
  print(list4.contains('1'));
  print(list4.contains(0));
  print(list4.lastIndexOf(0));

  //5.bien doi
  list4 = [2,1,3,9,0,10];
  print(list4);
  list4.sort();//ss tăng dần
  print(list4);
  list4.reversed;//đảo ngược
  print(list4.reversed);
  list4 = list4.reversed.toList();
  print(list4);
  var sublist = list4.sublist(1,3);
  print(sublist);
  var str_joined = list4.join(",");
  print(str_joined);
  //8.duyet cac ptu trong list


}