void main(){
  var r = ('first',a:2 ,5 ,10.5);
  var point = (123,456);
  var person = (name:'alice',age:25,5);
  //truy cap gia tri
  // Dùng chỉ số 
print(point.$1); // 123 
print(point.$2); // 456 

// Dùng tên 
print(person.name); 
print(person.age);
print(person.$1);






}