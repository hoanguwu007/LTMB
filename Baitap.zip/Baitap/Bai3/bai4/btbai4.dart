void main() {
  // Câu 1: Khai báo các biến với kiểu dữ liệu khác nhau
  print("cau1 =====================");
  int soNguyen = 10;
  double soThuc = 5.5;
  String chuoi = "Hello World!";
  bool laDung = true;
  print("Số nguyên: $soNguyen");
  print("Số thực: $soThuc");
  print("Chuỗi: $chuoi");
  print("Boolean: $laDung");

  print("cau2 =====================");
  // Câu 2: Gọi hàm calculateSum và in kết quả
  int sum = calculateSum(7, 3);
  print("Tổng của 7 và 3 là: $sum");
}
int calculateSum(int a, int b) {
  return a + b;
}
