/*cach khai bao bien: import '';
- su dung 'var' de dart tu suy luan kiểu
-khai báo với kiểu cụ thể
-khai báo bằng object
*/

void main()
{
  //tự suy luận kiểu
  var ten = 'hoangf'; // String
  var tuoi = 18; // int
  //khai bao kiểu dữ liệu cụ thể 
  String name = "Hoangf";
  int age = 18;

  //khai báo với object
  Object tenNguoiDung = 'hoangf';
  



}