void main ()
{
  print (2==2);
  print (2!=3);
  print (2>=3);

}