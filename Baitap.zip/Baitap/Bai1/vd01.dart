void main()
{
    //khai bao bien name
    String name = "Hoangf";
    int age = 18;
    /* ghi chu nhieu dong
    */
    if(age>=18)
    {
        print("Hello $name");
    }

    ///ghi chu documents
}