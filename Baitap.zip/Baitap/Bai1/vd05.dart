void main()
{

  //biến final được gán ít nhất 1 lần và có thể gán sau khi khai báo
  final name = 'hoangf';
  final int age;
  age = 18;
  //hằng số "const" khi khai báo phải gán giá trị liền ngay lập tức
  const color ='red';
  const int material =1;




}