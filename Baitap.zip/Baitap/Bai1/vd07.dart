
void main(){ 

int a = 5;
print(a++); // Step 1 => 5 a=6
print(++a); // Step 2 => a=7; =>[7 
print(a--); // Step 3 => 7; a=6; 
print(--a); // Step 4  => 5; a=5; 
print(a); // Step 5 a=5; 

}