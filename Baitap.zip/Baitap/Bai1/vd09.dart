void main ()
{
  Object obj ='hello';
  //kiem tra obj co phai la String

  if(obj is String)
  {
    print ('obj la chuoi');
  }
  //kiem tra obj k phai la String

  if(obj is! int)
  {
    print ("obj k phai la so nguyen");
  }

  //ep kieu
  String str = obj as String;
  print(str.toUpperCase());

}