void main()
{
  String? ten;
  ten = null;
  ten = 'hoangf';





}