void main()
{
  //phep tinh co ban

  int a = 5+3;
  int b = 10-4;
  int c = 3*4;
  double d= 10/2;
  int e= 7%3;//1
  print (d);
  //phep chia lay  phan nguyen
  int f = 7~/2;//chia lay phan nguyen
  print (f);
  //phep gan va tinh toan ket hop
  int x=10;
  x+5;//x=x+5
  x-=2;//x=x-2
  x~/=3;//x=x~/3; chia lay phan nguyen

  //tăng giảm 
  //++, --
  int y = 100;
  y++;//y = y +1;
  y--;//y = y -1;
  




}