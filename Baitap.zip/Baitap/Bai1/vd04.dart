//String moTa ="abcxyz";
//String? moTa;

//khai báo theo kiểu Lazy Initialization
late String moTa;



void main()
{
  moTa = 'HoangAnh';
  // moTa = null; muốn gán null phải có dấu '?'  dòng thứ 5 late String? moTa;
  print (moTa);




}